#!/usr/bin/env python3
# Description: Telegram translation bot using pyrogram


import logging
import random
import sys
import urllib.parse as urlparse
from urllib.parse import urlencode

import uvloop
from deep_translator import GoogleTranslator
from pyrogram import Client, filters, idle


# Configure logging
# Enable for telethon debug
# logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger("tradbot")
logger.setLevel(logging.DEBUG)
formatter = logging.Formatter(
    "%(asctime)s : %(name)s : %(funcName)s(%(lineno)d) : %(levelname)s : %(message)s"
)

# create console handler and set level to debug
console = logging.StreamHandler()
console.setLevel(logging.DEBUG)
console.setFormatter(formatter)
logger.addHandler(console)

# create file logger
filename = "tradbot.log"

file = logging.FileHandler(filename)
file.setLevel(logging.DEBUG)
file.setFormatter(formatter)
logger.addHandler(file)


uvloop.install()
api_id = ""  # await config("api_id")
api_hash = ""  # await config("api_hash")


app = Client("tradbot", api_id=api_id, api_hash=api_hash)


@app.on_message(filters.text & filters.private)
async def quitlooper(client, message):
    """
    Process incoming messages for /quit messages
    :param message: Update received
    """

    if message.text == "/quit":
        await message.reply("Quit received!")
        print("QUIT SENT")
        sys.exit(0)
    message.continue_propagation()


@app.on_message(filters.text)
async def id(client, message):
    """
    Process incoming messages for /id messages
    :param message: Update received
    """

    if message.text == "/id":
        await message.reply("Chat id is: %s" % message.chat.id)
    message.continue_propagation()


@app.on_message(filters.text)
async def traduce(client, message):
    """
    Process incoming messages for translation
    :param message: Update received
    """

    german = 0000000
    spanish = 00000000
    english = 0000000000

    # Only process messages received in english chat
    if message.text and message.chat.id == english:
        logger.debug("Message received: %s" % message.text)

        # Define translator
        trades = GoogleTranslator(source="auto", target="es")
        tradde = GoogleTranslator(source="auto", target="de")

        await app.send_message(chat_id=spanish, text=trades.translate(message.text))
        await app.send_message(chat_id=german, text=tradde.translate(message.text))

    message.continue_propagation()


async def main():
    # Main loop
    logger.debug("Starting execution loop")

    await app.start()
    await idle()


# Start the code
app.run(main())
