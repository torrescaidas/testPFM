#!/bin/bash

unset http_proxy
unset https_proxy

./tradbot.py
